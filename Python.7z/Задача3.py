def divider(arr):
    mid = (len(arr) + 1)//2
    slice_1 = arr[:mid]
    slice_2 = arr[mid:]
    print(slice_2 + slice_1)

my_st = "Hello"
divider(my_st)