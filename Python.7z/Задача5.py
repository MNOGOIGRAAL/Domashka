def form(a1, b1):
    c1 = a1 + b1
    c2 = a1 * b1
    print(f"'a + b = c' -> {a1} + {b1} = {c1}\n"
          f"'a * b = c' -> {a1} * {b1} = {c2}" )

a = 73
b = 95
form(a, b)