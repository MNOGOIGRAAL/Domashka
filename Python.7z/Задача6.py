def counter_symbol(arr):
    low_arr = arr.lower()
    symbols = 0
    for i in low_arr:
        if i == "е":
            symbols += 1
    print(f"Кол-во символов 'e' в строке '{arr}': {symbols}")


my_str = "в Ереване"
counter_symbol(my_str)