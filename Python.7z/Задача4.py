def delet_case(arr):
    first = arr.find("h")
    last = arr.rfind("h")

    new_my_list = my_list[:first] + my_list[last + 1:]
    print(f"Текст в котором первое и последнее вхождение буквы h, "
          f"а также все символы, находящиеся между ними удалены:\n{new_my_list}")

my_list = "In the hole in the ground there lived a hobbit"
delet_case(my_list)