def reversal(arr):
    revers = arr[::-1]
    sub_str = []
    for i in range(0, len(revers)):
        sub_str.append(revers[i:])

    print(f"{arr} -> {sub_str}")






my_str = "1234"
reversal(my_str)