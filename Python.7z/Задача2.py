def couter(arr):
    new_st = arr.split()
    print(my_st)
    print(f"Слов в стркое: {len(new_st)}")

my_st = "Шла Саша по шоссе и сосала сушку"

couter(my_st)