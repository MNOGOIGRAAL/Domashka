def number_bracket(arr):
    opening_bracket = 0
    closing_bracket = 0
    for i in arr:
        if i == "(":
            opening_bracket += 1
        elif i == ")":
            closing_bracket += 1
    return opening_bracket, closing_bracket

def find_pair(a, b):
    if a == b:
        print(f"В строке {a} пары скобок. Все на месте!")
    else:
        x = a - b
        print(f"В выражении пропущены {abs(x)} скобок")

my_str = "6 - (12 * (2+3)/(5+6))"
opening_bracket, closing_bracket = number_bracket(my_str)
find_pair(opening_bracket, closing_bracket)