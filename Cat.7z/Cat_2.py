from CatSuper import Cat
from Deco import decorator

@decorator
class BigCat(Cat):

    def eat(self):
        print(f"Меня зовут {self.name} и я ОЧЕНЬ МНОГО кушаю")


    def sleep(self):
        print(f"Меня зовут {self.name} и я сплю по 17 часов")


    def run(self):
        print(f"Меня зовут {self.name} и я ненавижу бегать")