from CatSuper import Cat
from Deco import decorator

@decorator
class SmallCat(Cat):

    def eat(self):
        print(f"Меня зовут {self.name} и я мало кушаю")

    def sleep(self):
        print(f"Меня зовут {self.name} и я сплю по 12 часов")

    def run(self):
        print(f"Меня зовут {self.name} и я люблю бегать")