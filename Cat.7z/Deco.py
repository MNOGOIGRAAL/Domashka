import time
def decorator(func):
    def wrapper(n):
        start_time = time.time()
        print("Начало")
        res = func(n)
        print(f"Время выполнения: {time.time() - start_time:.4f} секунд")
        print("Конец")
        return res
    return wrapper