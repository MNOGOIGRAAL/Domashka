from Cat_1 import SmallCat
from Cat_2 import BigCat


cat_Shiha = SmallCat("Шуша")
cat_Shiha.eat()

cat_Jojo = BigCat("Жожо")
cat_Jojo.eat()