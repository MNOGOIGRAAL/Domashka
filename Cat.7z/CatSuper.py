class Cat:
    def __init__(self, name):
        self.name = name


    def eat(self):
        pass


    def sleep(self):
        pass


    def run(self):
        pass