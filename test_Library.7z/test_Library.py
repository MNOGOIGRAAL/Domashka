from File_library import Library

def test_library():
    library_1 = Library("Городская библиотека", "Ул. Ленина 60", 250)
    library_2 = Library("Библиотека имени Чехова", "Ул. Чехова 50", 100)

    library_1 = library_1 + 10
    assert library_1.numb_book == 260, "Ошибка при добавлении книг"
    print("Добавление книг - Passed")

    library_1 = library_1 - 60
    assert library_1.numb_book == 200, "Ошибка при вычитании книг"
    print("Вычитание книг - Passed")

    library_1 += 200
    assert library_1.numb_book == 400, "Ошибка +="
    print("'+=' - Passed")

    library_1 -= 150
    assert library_1.numb_book == 250, "Ошибка -="
    print("'-=' - Passed")

    assert library_2 < library_1, "Ошибка <"
    print("'<' - Passed")
    assert library_1 > library_2, "Ошибка >"
    print("'>' - Passed")
    assert library_2 <= library_1, "Ошибка <="
    print("'<=' - Passed")
    assert library_1 >= library_2, "Ошибка >="
    print("'>=' - Passed")
    assert library_1 == Library("Городская библиотека", "Ул. Ленина 60", 250), "Ошибка =="
    print("'==' - Passed")
    assert library_1 != library_2, "Ошибка !="
    print("'!=' - Passed")


test_library()