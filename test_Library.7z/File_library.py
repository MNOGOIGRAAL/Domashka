class Library:
    def __init__(self, name, location, numb_book=0):
        self.name = name
        self.location = location
        self.numb_book = numb_book

    def __add__(self, other): # +
        return Library(self.name, self.location, self.numb_book + other)

    def __sub__(self, other): # -
        return Library(self.name,self.location, self.numb_book - other)

    def __iadd__(self, other): # +=
        self.numb_book += other
        return self

    def __isub__(self, other): #-=
        self.numb_book -= other
        return self

    def __lt__(self, other): # <
        return self.numb_book < other.numb_book

    def __gt__(self, other): # >
        return self.numb_book > other.numb_book

    def __le__(self, other): # <=
        return self.numb_book <= other.numb_book

    def __ge__(self, other): # >=
        return self.numb_book >= other.numb_book

    def __eq__(self, other): # ==
        return self.numb_book == other.numb_book

    def __ne__(self, other): #  !=
        return self.numb_book != other.numb_book